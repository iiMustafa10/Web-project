<?php
define('DB_HOST', 'localhost');
define('DB_USER_NAME', 'root');
define('DB_USER_PASSWORD', '');
define('DB_NAME', 'blog');
?>